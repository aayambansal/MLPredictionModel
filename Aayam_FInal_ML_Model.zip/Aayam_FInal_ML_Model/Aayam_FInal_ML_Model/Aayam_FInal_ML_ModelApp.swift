//
//  Aayam_FInal_ML_ModelApp.swift
//  Aayam_FInal_ML_Model
//
//  Created by Aayam on 8/3/24.
//

import SwiftUI

@main
struct Aayam_FInal_ML_ModelApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
